#!/bin/bash
/opt/anaconda3/bin/python hw1.py "$1"
